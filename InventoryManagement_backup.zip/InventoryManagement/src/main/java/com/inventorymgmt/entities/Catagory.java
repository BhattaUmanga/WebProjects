package com.inventorymgmt.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Shailesh
 */
@Entity
@Table(name = "CATAGORY")

public class Catagory implements Serializable {

    @Id
    @Column(name = "CATEGORY_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer categoryId;

    @Column(name = "CATEGORY_NAME")
    private String catagoryName;

    @Column(name = "REMARKS")
    private String catagoryRemarks;

    public Catagory() {
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getCatagoryName() {
        return catagoryName;
    }

    public void setCatagoryName(String catagoryName) {
        this.catagoryName = catagoryName;
    }

    public String getCatagoryRemarks() {
        return catagoryRemarks;
    }

    public void setCatagoryRemarks(String catagoryRemarks) {
        this.catagoryRemarks = catagoryRemarks;
    }
}
