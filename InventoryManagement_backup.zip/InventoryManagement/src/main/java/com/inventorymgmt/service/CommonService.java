/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.inventorymgmt.service;

import java.util.List;

/**
 *
 * @author Shailesh
 */
public interface CommonService<T> {

    public void save(T obj);

    public List<T> findAll();

    public void update(T obj);

    public T findById(int id);

    public void delete(T obj);

    public T findByName(String type);

    public long count();
}
