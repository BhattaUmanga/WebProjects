package com.inventorymgmt.rest.resource;

import com.inventorymgmt.entities.Catagory;
import com.inventorymgmt.service.CatagoryService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

/**
 *
 * @author user
 */
//@CrossOrigin(origins = "*", maxAge = 3600)
//@RestController
//public class CategoryResource {
//
////    @PostMapping(path = {"/rest/create"})
//    @RequestMapping(path = {"rest/create"}, consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON, method = RequestMethod.POST)
//    public String create(@RequestBody String userName) {
//        System.out.println("-- inside create method -- ");
//        System.out.println("value :: " + userName);
//        
//        return "hello";
//    }
//}
@RestController
@RequestMapping("/rest/category")
@EnableWebMvc

public class CategoryResource {

    @Autowired
    CatagoryService categoryService;

    @RequestMapping(value = "/allCat", method = RequestMethod.GET)
    public List<Catagory> getAllCategory() {
        System.out.println("\nFetching all categories\n");

        return categoryService.findAll();
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public Catagory findCategoryById(@PathVariable("id") int id) {
        System.out.println("\nFetching category by id = " + id + "\n");
        return categoryService.findById(id);
    }

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public void saveCategory(@RequestBody Catagory categoryModel) {
        categoryService.save(categoryModel);
    }

    @RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
    public void deleteCategory(@PathVariable int id) {
        categoryService.delete(categoryService.findById(id));
    }

    @RequestMapping(value = "/update/{id}", method = RequestMethod.POST)
    public void updateCategory(@RequestBody Catagory categoryModel) {
        categoryService.update(categoryModel);
    }
}
