package com.inventorymgmt.repository;

import com.inventorymgmt.entities.Catagory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface CatagoryRepository extends
        JpaRepository<Catagory, Integer> {

    @Modifying
    @Transactional
    @Query("update Catagory c set c.catagoryName = :name,"
            + " c.catagoryRemarks = :remarks"
            + " where c.categoryId = :id")
    public void updateCatagory(@Param("name") String name,
            @Param("remarks") String remarks,
            @Param("id") int id);

    @Query("select c from Catagory c where c.catagoryName = :name")
    public Catagory findByName(@Param("name") String name);
}
