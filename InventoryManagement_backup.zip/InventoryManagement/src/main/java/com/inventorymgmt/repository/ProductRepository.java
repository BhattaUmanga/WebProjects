package com.inventorymgmt.repository;

import com.inventorymgmt.entities.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface ProductRepository extends JpaRepository<Product, Integer> {

    @Modifying
    @Transactional
    @Query("update Product p set p.productName = :name,"
            + " p.productPrice = :price,"
            + " p.productQuantity = :quantity,"
            + " p.productRemarks = :remarks,"
            + " p.catagory_id.categoryId = :catId"
            + " where p.productId = :id")
    public void updateProduct(
            @Param("name") String name,
            @Param("price") double price,
            @Param("quantity") int quantity,
            @Param("remarks") String remarks,
            @Param("catId") int catId,
            @Param("id") int id);   
}
