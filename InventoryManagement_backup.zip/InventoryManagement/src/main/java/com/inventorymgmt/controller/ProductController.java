package com.inventorymgmt.controller;

import com.inventorymgmt.entities.Product;
import com.inventorymgmt.service.CatagoryService;
import com.inventorymgmt.service.ProductService;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/product")
public class ProductController {

    @Autowired
    ProductService productService;

    @Autowired
    CatagoryService categoryService;

    @RequestMapping(method = RequestMethod.GET, value = "/addPro")
    public String addProduct(@ModelAttribute("displayProductForm")
            @Valid Product product, Model m) {
        System.out.println("Loading Add Product Page ");

        m.addAttribute("catList", categoryService.findAll());
        return "addProduct";
    }

    @RequestMapping(method = RequestMethod.POST, value = "/addPro")
    public String saveProduct(@ModelAttribute("displayProductForm")
    @Valid Product product) {

        productService.save(product);
        System.out.println("---- saved successfully --------");

        return "redirect:/product/listPro";
    }

    @RequestMapping(method = RequestMethod.GET, value = "/listPro")
    public String productList(Model pl) {

        pl.addAttribute("list", productService.findAll());
        System.out.println("Listing All Products");

        return "listProducts";
    }

    @RequestMapping(method = RequestMethod.GET, value = "/delPro/{id}")
    public String deleteProduct(@PathVariable("id") int proId) {

        Product findById = productService.findById(proId);
        productService.delete(findById);

        System.out.println("product successfully deleted with id = " + proId);

        return "redirect:/product/listPro";
    }

    @RequestMapping(method = RequestMethod.GET, value = "/updatePro/{id}")
    public String editProduct(@PathVariable("id") int proId, Model m) {

        Product findById = productService.findById(proId);

        m.addAttribute("obj", findById);
        m.addAttribute("catList", categoryService.findAll());

        return "updateProduct";
    }

    @RequestMapping(method = RequestMethod.POST, value = "/updatePro/upd")
    public String updateProduct(@ModelAttribute Product p) {

        productService.update(p);
        System.out.println("Product Updated with ID= " + p.getProductId());
        return "redirect:/product/listPro";

    }

}
