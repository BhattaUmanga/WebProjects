package com.inventorymgmt.controller;

import com.inventorymgmt.service.CatagoryService;
import com.inventorymgmt.service.ProductService;
import java.security.Principal;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class LoginController {

    @Autowired
    CatagoryService categoryService;

    @Autowired
    ProductService productService;

    @RequestMapping(method = RequestMethod.GET,
            value = {"/", "login"})
    public String loginPage() {

        return "login";
    }

    @RequestMapping(value = "/welcome")
    public String welcomePage(HttpServletRequest hsr, Model m) {

        Principal obj = hsr.getUserPrincipal();
        System.out.println("Obj :: " + obj);
        if (obj == null) {
            m.addAttribute("Hello", "Please login");
//            System.out.println("Please Login first ");
            return "login";
        }

        m.addAttribute("totalCat", categoryService.count());
        m.addAttribute("totalProd", productService.count());
        return "dashboard";
    }

    @RequestMapping(value = "/loginFailed", method = RequestMethod.GET)
    public String loginFailed(Model m) {
        System.out.println("loginFailed");

        m.addAttribute("LoginFailed", "invalid Credentials");
        return "login";
    }

    @RequestMapping(value = "/403")
    public String accessDenied(Model m) {

        m.addAttribute("denied", "Access denied");
        return "accessDenied";
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logout(HttpServletRequest request,
            HttpServletResponse response, Model m) {

        Authentication a = SecurityContextHolder.getContext().getAuthentication();
        if (a != null) {
            new SecurityContextLogoutHandler().logout(request, response, a);
        }

        return "redirect:/";
    }
}
