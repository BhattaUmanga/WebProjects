package com.inventorymgmt.controller;

import com.inventorymgmt.entities.Catagory;
import com.inventorymgmt.service.CatagoryService;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/catagory")
public class CatagoryController {

    @Autowired
    CatagoryService categoryService;

    @RequestMapping(method = RequestMethod.GET, value = "/addCat")
    public String addCatagory(@ModelAttribute("displayCatagoryForm") @Valid Catagory catagory) {
        System.out.println("Loading Add Catagory Page ");

        return "addCatagory";
    }

    @RequestMapping(method = RequestMethod.POST, value = "/addCat")
    public String saveCatagory(@ModelAttribute("displayCatagoryForm") @Valid Catagory catagory, Model model) {

        if (catagory.getCatagoryName() == null || catagory.getCatagoryName().equals("")) {
            model.addAttribute("emptyName", "Category name is required");
            return "addCatagory";
        }
        if (catagory.getCatagoryRemarks() == null || catagory.getCatagoryRemarks().equals("")) {
            model.addAttribute("emptyRemarks", "Category remark is required");
            return "addCatagory";
        }

        Catagory isPresent = categoryService.findByName(catagory.getCatagoryName());
        if (isPresent != null) {
            model.addAttribute("alreadyExists", catagory.getCatagoryName() + " already exists");
            return "addCatagory";
        } else {
            categoryService.save(catagory);
            System.out.println("---- saved successfully --------");
            return "redirect:/catagory/listCat";
        }
    }

    @RequestMapping(method = RequestMethod.GET, value = "/listCat")
    public String catagoryList(Model cl) {

        cl.addAttribute("list", categoryService.findAll());
        System.out.println("categoryList :: " + categoryService.findAll());
        System.out.println("Listing All Catagories");

        return "listCatagories";
    }

    @RequestMapping(method = RequestMethod.GET, value = "/delCat/{id}")
    public String deleteCatagory(@PathVariable("id") int catId) {

        Catagory categoryObj = categoryService.findById(catId);

        categoryService.delete(categoryObj);

        System.out.println("catagory successfully deleted with " + "id = " + catId);

        return "redirect:/catagory/listCat";
    }

    @RequestMapping(method = RequestMethod.GET, value = "/updateCat/{id}")
    public String editCatagory(@PathVariable("id") int catId, Model model) {

        Catagory findById = categoryService.findById(catId);

        model.addAttribute("obj", findById);

        return "updateCatagory";
    }

    @RequestMapping(method = RequestMethod.POST, value = "/updateCat/upd")
    public String updateCatagory(@ModelAttribute Catagory categoryObj) {

        categoryService.update(categoryObj);
        System.out.println("Catagory Updated with ID = " + categoryObj.getCategoryId());
        return "redirect:/catagory/listCat";
    }
}
