package com.inventorymgmt.serviceimpl;

import com.inventorymgmt.entities.Catagory;
import com.inventorymgmt.repository.CatagoryRepository;
import com.inventorymgmt.service.CatagoryService;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class CatagoryServiceImpl implements CatagoryService {

    @Autowired
    CatagoryRepository categoryRepository;

    @Override
    public void save(Catagory obj) {
        categoryRepository.save(obj);
    }

    @Override
    public List<Catagory> findAll() {
        return categoryRepository.findAll();
    }

    @Override
    public void update(Catagory obj) {
        categoryRepository.updateCatagory(obj.getCatagoryName(), obj.getCatagoryRemarks(),
                obj.getCategoryId());
    }

    @Override
    public Catagory findById(int id) {
        return categoryRepository.findOne(id);
    }

    @Override
    public void delete(Catagory obj) {
        categoryRepository.delete(obj);
    }

    @Override
    public Catagory findByName(String name) {
        return categoryRepository.findByName(name);
    }

    @Override
    public long count() {
        return categoryRepository.count();
    }
}
