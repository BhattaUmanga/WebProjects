package com.inventorymgmt.serviceimpl;

import com.inventorymgmt.entities.Product;
import com.inventorymgmt.repository.ProductRepository;
import com.inventorymgmt.service.ProductService;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

    @Autowired
    ProductRepository pr;

    @Override
    public void save(Product obj) {
        pr.save(obj);
    }

    @Override
    public List<Product> findAll() {
        return pr.findAll();
    }

    @Override
    public void update(Product obj) {
        pr.updateProduct(obj.getProductName(),
                obj.getProductPrice(),
                obj.getProductQuantity(),
                obj.getProductRemarks(),
                obj.getCatagory_id().getCategoryId(),
                obj.getProductId());
    }

    @Override
    public Product findById(int id) {
        return pr.findOne(id);
    }

    @Override
    public void delete(Product obj) {
        pr.delete(obj);
    }

    @Override
    public Product findByName(String type) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public long count() {
        return pr.count();
    }

}
